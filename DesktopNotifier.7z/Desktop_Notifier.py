import time
import plyer
from plyer import notification

if __name__ == "__main__":
    while True:
        notification.notify(
            title="*** AARAM KRLE BHAI!!",
            message="BHAI AARAM KRLE ASE 24 GHANTE PC K SAMNE BETHE REHNE SE HEALTH ACHI NHI HOTI",
            #app_icon= "D:\CODES\PYTHON CODES\New folder\icon.ico",
            timeout=10
        )
        time.sleep(20)
